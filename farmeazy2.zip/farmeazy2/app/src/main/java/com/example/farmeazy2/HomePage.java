package com.example.farmeazy2;

import static java.lang.System.out;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;

public class HomePage extends AppCompatActivity {
    String[] features = {"Predict Crop", "Blogs", "Profile"};
    ListView listView;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home_page);
        getSupportActionBar().hide();
        listView = (ListView) findViewById(R.id.card_list);
        ArrayAdapter adapter = new ArrayAdapter(this, R.layout.home_card_list, R.id.home_feature, features);
        listView.setAdapter(adapter);

      listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
          @Override
          public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
              Intent intent=new Intent(HomePage.this,opinion.class);
          }
      });




    }


}
