package com.example.farmeazy2;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

public class opinion extends AppCompatActivity {
    String[] opinions = {"opinion1", "opinion2", "opinion3"};
    ListView lv;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.opinion);
        getSupportActionBar().hide();
        lv = (ListView) findViewById(R.id.card_list);
        ArrayAdapter adapter = new ArrayAdapter(this, R.layout.home_card_list, R.id.home_feature, opinions);
        lv.setAdapter(adapter);


    }
}
